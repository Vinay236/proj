package com.cg.iqgexception;

public class IQGException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6332362098319843991L;

	public IQGException(String message) {
		
		super(message);
	}

}

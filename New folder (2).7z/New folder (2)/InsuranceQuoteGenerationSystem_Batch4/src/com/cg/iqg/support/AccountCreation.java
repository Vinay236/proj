package com.cg.iqg.support;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.iqg.model.Accounts;
import com.cg.iqg.service.InsuranceService;
import com.cg.iqg.serviceimpl.InsuranceServiceImpl;
import com.cg.iqgexception.IQGException;

public class AccountCreation {

	Scanner scanner=null;
	int accountNumber=0;
	InsuranceService service=new InsuranceServiceImpl();
	public int createAccount( String userName){
		String insuredName = "";
		String insuredStreet = "";
		String insuredCity = "";
		String insuredState = "";
		int insuredZip = 0;
		String businessSeg = "";
		boolean zipFlag = false;
		scanner=new Scanner(System.in);
		System.out.println("Enter insured Name: ");
		insuredName = scanner.nextLine();

		System.out.println("Enter insured Street: ");
		insuredStreet = scanner.nextLine();

		System.out.println("Enter insured City: ");
		insuredCity = scanner.nextLine();

		System.out.println("Enter insured State: ");
		insuredState = scanner.nextLine();

		do {
			System.out.println("Enter insured Zip: ");
			scanner = new Scanner(System.in);
			try {

				insuredZip = scanner.nextInt();
				zipFlag = true;

			} catch (InputMismatchException e) {

				System.err.println("Enter digits only");
				zipFlag = false;
			}

		} while (!zipFlag);

		scanner.nextLine();

		System.out.println("Enter business Segment: ");
		businessSeg = scanner.nextLine();
		Accounts accounts=new Accounts(insuredName, insuredStreet, insuredCity, insuredState, insuredZip, businessSeg,userName);
		boolean validFlag=false;
		try {
			validFlag = service.validFields(accounts);
		} catch (IQGException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if(validFlag==true)
		{
			try {
					accountNumber=service.createAccount(accounts);
			
			}catch (IQGException e) {
				System.err.println(e.getMessage());
			}			
		}
		return accountNumber;
	}
}

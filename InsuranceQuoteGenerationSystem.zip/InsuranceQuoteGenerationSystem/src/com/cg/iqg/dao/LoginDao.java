package com.cg.iqg.dao;
import com.cg.iqg.model.UserRole;
import com.cg.iqg.utility.JDBCUtility;

import java.sql.*;

public class LoginDao {
	public static boolean validate(UserRole user) {
		boolean status = false;
		
		try {
			
			Connection con = JDBCUtility.getConnection();
			PreparedStatement ps = con.prepareStatement(QueryMapper.logIn);
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getPassword());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}
	
	public static String getRoleCode(UserRole user) {
		String role="";
		
		try {
				Connection con = JDBCUtility.getConnection();
				PreparedStatement ps = con.prepareStatement("select role_code from user_role where user_name=?");
				ps.setString(1, user.getUserName());
				ResultSet rs1 = ps.executeQuery();
				rs1.next();
				role = rs1.getString(1);
				System.out.println(role);
			} catch (Exception e) {
				System.out.println(e);
		}
		return role;
	}
}

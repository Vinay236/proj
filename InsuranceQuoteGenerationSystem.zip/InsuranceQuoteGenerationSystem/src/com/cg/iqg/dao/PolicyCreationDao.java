package com.cg.iqg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.iqg.model.Accounts;
import com.cg.iqg.model.Policy;
import com.cg.iqg.model.PolicyDetails;
import com.cg.iqg.utility.JDBCUtility;

public class PolicyCreationDao {

	public static long createPolicy(Policy policy) {
		long accno = 0;
		try {
			
			Connection con = JDBCUtility.getConnection();
			
			
			
			PreparedStatement ps = ps = con.prepareStatement(QueryMapper.insertInPolicy);
			ps.setDouble(1, policy.getPolicyPremium());
			ps.setLong(2, policy.getAccountNumber());
			
			ResultSet rs = ps.executeQuery();
			rs.next();
			
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return accno;
	}
	
	public static String getBusType(Policy policy) {
		String bus_type="";
		try {
			
			Connection con = JDBCUtility.getConnection();
			
			PreparedStatement ps = ps = con.prepareStatement(QueryMapper.getBuisnessSegment);
			ps.setLong(1, policy.getAccountNumber());
			
			ResultSet rs = ps.executeQuery();
			rs.next();
			
			bus_type = rs.getString(1);
			System.out.println(bus_type);
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return bus_type;
	}
	
	public static long getPolicyNumber(Policy policy) {
		long policynum = 0;
		try {
			
			Connection con = JDBCUtility.getConnection();
			
			PreparedStatement ps = ps = con.prepareStatement("SELECT policy_number from policy where account_number=?");
			ps.setLong(1, policy.getAccountNumber());
			
			ResultSet rs = ps.executeQuery();
			rs.next();
			
			policynum = rs.getLong(1);
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return policynum;
	}
	
	public static String getQuestionId(int ques) {
		String ques_id="";
		try {
			
			Connection con = JDBCUtility.getConnection();
			
			PreparedStatement ps = ps = con.prepareStatement("SELECT pol_ques_id from policy_questions where pol_ques_seq=?");
			ps.setLong(1, ques);
			
			ResultSet rs = ps.executeQuery();
			rs.next();
			
			ques_id = rs.getString(1);
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return ques_id;
	}
	
	
	
	
	public static long insertPolicyDetails(PolicyDetails policy) {
		long accno = 0;
		try {
			
			Connection con = JDBCUtility.getConnection();
			
			
			
			PreparedStatement ps = ps = con.prepareStatement(QueryMapper.insertPolicyDetails);
			ps.setLong(1, policy.getPolicyNumber());
			ps.setString(2, policy.getQuestionID());
			ps.setString(3, policy.getAnswer());
		
			ResultSet rs = ps.executeQuery();
			rs.next();
			
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return accno;
	}
}


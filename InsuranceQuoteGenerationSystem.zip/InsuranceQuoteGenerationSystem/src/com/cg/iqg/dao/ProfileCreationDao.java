package com.cg.iqg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.iqg.model.UserRole;
import com.cg.iqg.utility.JDBCUtility;

public class ProfileCreationDao {

	public static boolean createProfile(UserRole user) {
		boolean status = false;
		try {
			
			Connection con = JDBCUtility.getConnection();
			PreparedStatement ps = con.prepareStatement(QueryMapper.createProfile);
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getRoleCode());
			
			
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return status;
	}
}

package com.cg.iqg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.iqg.model.Accounts;
import com.cg.iqg.utility.JDBCUtility;

public class AccountDao {

	public static long createAccount(Accounts account) {
		long accno = 0;
		try {
			
			Connection con = JDBCUtility.getConnection();
			PreparedStatement ps = con.prepareStatement(QueryMapper.InsertData);
			ps.setString(1, account.getInsuredName());
			ps.setString(2, account.getInsuredStreet());
			ps.setString(3, account.getInsuredCity());
			ps.setString(4, account.getInsuredState());
			ps.setInt(5, account.getInsuredZip());
			ps.setString(6, account.getBusinessSegment());
			ps.setString(7, account.getUserName());
			
			ResultSet rs = ps.executeQuery();
			rs.next();
			
			ps = con.prepareStatement("select account_number from accounts where user_name=?");
			ps.setString(1, account.getUserName());
			ResultSet rs1 = ps.executeQuery();
			rs1.next();
			accno = rs1.getLong(1);
			System.out.println(accno);
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return accno;
	}
	
	public static boolean userExist(Accounts account) {
		boolean status = false;
try {
			
			Connection con = JDBCUtility.getConnection();
			PreparedStatement ps = con.prepareStatement(QueryMapper.getUser);
			ps.setString(1, account.getUserName());
		
			
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
	return status;
	}
}

package com.cg.iqg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.iqg.utility.JDBCUtility;

public class PolicyCreationMidDao {

	public static int getBusinessSegment(long accno) {
		
		int bus_seg_seq=0;
		boolean status = false;
		
		try {
			
			Connection con = JDBCUtility.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT business_segment FROM accounts WHERE account_number=?");
			ps.setLong(1, accno);
			
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			String bus_seg_name = rs.getString(1);
			
			ps = con.prepareStatement("SELECT bus_seg_seq from Business_Segment where bus_seg_id=?");
			ps.setString(1, bus_seg_name);
			ResultSet rs1 = ps.executeQuery();
			status = rs1.next();
			bus_seg_seq = rs1.getInt(1);
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return bus_seg_seq;
	}
}

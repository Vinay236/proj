package com.cg.iqg.model;

public class PolicyDetails {
	
	private Long policyNumber;
	private String questionID;
	private String answer;
	
	public PolicyDetails() {
		// TODO Auto-generated constructor stub
	}

	public PolicyDetails(Long policyNumber, String questionID, String answer) {
		super();
		this.policyNumber = policyNumber;
		this.questionID = questionID;
		this.answer = answer;
	}
	
	public PolicyDetails(String questionID, String answer) {
		super();
		this.questionID = questionID;
		this.answer = answer;
	}

	public Long getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(Long policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getQuestionID() {
		return questionID;
	}

	public void setQuestionID(String questionID) {
		this.questionID = questionID;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "PolicyDetails [policyNumber=" + policyNumber + ", questionID=" + questionID + ", answer=" + answer
				+ "]";
	}
	
	

}

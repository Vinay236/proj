package com.cg.iqg.daoimpl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.iqg.dao.AccountDao;
import com.cg.iqg.dao.PolicyCreationDao;
import com.cg.iqg.model.Accounts;
import com.cg.iqg.model.Policy;
import com.cg.iqg.model.PolicyDetails;

@WebServlet("/PolicyCreation")
public class PolicyCreationDaoImpl extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
		
	    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	    
	    Long acc = Long.parseLong(request.getParameter("acc_no"));     
	   
	    Policy policy = new Policy(0.0, acc);
	    
	    PolicyCreationDao.createPolicy(policy);
	    
	    String bus_type = PolicyCreationDao.getBusType(policy);
	    
	    long pol_num = PolicyCreationDao.getPolicyNumber(policy);
	    
	    System.out.println(pol_num);
	    
	    if(bus_type.equals("rest")) {
	    for(int i=111; i<120; i++) {
	    	String ques_id = PolicyCreationDao.getQuestionId(i);
	    	String ans = request.getParameter(Integer.toString(i));
	    	PolicyDetails policy1 = new PolicyDetails(pol_num, ques_id, ans);
	    	PolicyCreationDao.insertPolicyDetails(policy1);
	    }
	    }
	    out.close();  
	    }  
	}  

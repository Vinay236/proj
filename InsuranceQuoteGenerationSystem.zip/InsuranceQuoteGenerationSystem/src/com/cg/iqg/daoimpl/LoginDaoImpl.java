package com.cg.iqg.daoimpl;
import com.cg.iqg.dao.LoginDao;
import com.cg.iqg.model.UserRole;

	import java.io.IOException;  
	import java.io.PrintWriter;  
	  
	import javax.servlet.RequestDispatcher;  
	import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;  
	import javax.servlet.http.HttpServletRequest;  
	import javax.servlet.http.HttpServletResponse;  
	  
	@WebServlet("/Login")
	public class LoginDaoImpl extends HttpServlet {  
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
		
	    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	          
	    String n=request.getParameter("Login_ID");  
	    String p=request.getParameter("Password");  
	    
	    UserRole user = new UserRole(n,p);
	    
	    
	    if(LoginDao.validate(user)){  
	    	if(LoginDao.getRoleCode(user).equals("Admin"))
	    	{
	        RequestDispatcher rd=request.getRequestDispatcher("FrameAdmin.html");  
	        rd.forward(request,response);  
	    	}
	    	else if(LoginDao.getRoleCode(user).equals("Agent"))
	    	{
	        RequestDispatcher rd=request.getRequestDispatcher("FrameAgent.html");  
	        rd.forward(request,response);  
	    	}
	    	else {
	    		 RequestDispatcher rd=request.getRequestDispatcher("FrameInsured.html");  
	 	        rd.forward(request,response);
	    	}
	    }  
	    else{  
	    	String txt1 = "Invalid Username or Password!!";
	    	out.println("<script type=\"text/javascript\">alert('"+txt1+"');");
	    	out.println("location='Login.jsp'");
	    	out.println("</script>");
	    }  
	          
	    out.close();  
	    }  
	}  

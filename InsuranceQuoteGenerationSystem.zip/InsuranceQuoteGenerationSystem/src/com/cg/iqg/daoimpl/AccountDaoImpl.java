package com.cg.iqg.daoimpl;

import com.cg.iqg.model.Accounts;
import com.cg.iqg.dao.AccountDao;
import com.cg.iqg.dao.LoginDao;
import com.cg.iqg.model.UserRole;
import java.io.IOException;  
import java.io.PrintWriter;    
import javax.servlet.RequestDispatcher;  
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
	  
@WebServlet("/AccountCreation")
public class AccountDaoImpl extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
		
	    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	    
	    String uname = request.getParameter("User_Name");  
	    String name = request.getParameter("Insured_Name");  
	    String street = request.getParameter("Insured_Street");  
	    String city = request.getParameter("Insured_City");  
	    String state = request.getParameter("Insured_State");  
	    Integer zip = Integer.parseInt(request.getParameter("Insured_Zip"));  
	    String bus_seg = request.getParameter("Business_Segment");  
	     
	    
	    Accounts acc = new Accounts(name, street, city, state, zip, bus_seg, uname);
	    
	    if(!AccountDao.userExist(acc)) {
	    long accno = AccountDao.createAccount(acc);
	    String txt = "Account Created Successfully!! Your Account Number: "+accno;
	    if(accno!=0) {
	    	out.println("<script type=\"text/javascript\">alert('"+txt+"');");
	    	out.println("location='Login.jsp'");
	    	out.println("</script>");
	    	//RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");  
	        //rd.forward(request,response); 
	    }
	    else {
	    	RequestDispatcher rd=request.getRequestDispatcher("AccountCreation.jsp");  
	        rd.forward(request,response);
	    }
	    }
	    else
	    {
	    	String txt = "Account Already Exists!!";
	    	out.println("<script type=\"text/javascript\">alert('"+txt+"');");
	    	out.println("location='AccountCreation.jsp'");
	    	out.println("</script>");
	    }
	          
	    out.close();  
	    }  
	}  

package com.cg.iqg.daoimpl;

import javax.servlet.annotation.WebServlet;

import com.cg.iqg.dao.ProfileCreationDao;

import com.cg.iqg.model.UserRole;

	import java.io.IOException;  
	import java.io.PrintWriter;  
	  
	import javax.servlet.RequestDispatcher;  
	import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;  
	import javax.servlet.http.HttpServletRequest;  
	import javax.servlet.http.HttpServletResponse;  
	
@WebServlet("/ProfileCreation")
public class ProfileCreationDaoImpl extends HttpServlet{
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
		
	    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	    
	    String uname = request.getParameter("User_Name");  
	    String pwd = request.getParameter("Password");  
	    String rolecode = request.getParameter("Role_Code");  
	    
	     
	    
	    UserRole user = new UserRole(uname, pwd, rolecode);
	    
	    String txt = "Profile Created Successfully!!";
	    
	    if(ProfileCreationDao.createProfile(user)) {
	    	out.println("<script type=\"text/javascript\">alert('"+txt+"');");
	    	out.println("location='Login.jsp'");
	    	out.println("</script>");
	    	//RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");  
	        //rd.forward(request,response); 
	    }
	    else {
	    	String txt1 = "Username Already Exist!!";
	    	out.println("<script type=\"text/javascript\">alert('"+txt1+"');");
	    	out.println("location='Login.jsp'");
	    	out.println("</script>");
	    }
	    
	          
	    out.close();  
	    }  
	
}
